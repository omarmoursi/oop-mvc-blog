# Advanced PHP MVC Blog

A simple blog written in php with advanced use of oop with different design patterns

# Watch The full Course

You can watch the full course for this blog on youtube on the following link

https://www.youtube.com/playlist?list=PLGO8ntvxgiZPZBHUGED6ItUujXylNGpMH