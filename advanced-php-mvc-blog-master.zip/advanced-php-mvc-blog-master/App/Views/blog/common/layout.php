<?php echo $header;?>
<?php echo $content;?>
<?php echo $sidebar;?>
<?php echo $footer;?>